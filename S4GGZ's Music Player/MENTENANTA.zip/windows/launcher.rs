#![windows_subsystem = "windows"]

#[cfg(not(all(target_os = "windows", target_arch = "x86_64")))]
compile_error!("The S4GGZ launcher supports Windows x64 only.");

use std::{ffi::c_void, os::windows::ffi::OsStrExt, process::{Command, ExitCode}};

#[link(name = "user32")]
extern "system" {
    fn MessageBoxW(window: *mut c_void, text: *const u16, caption: *const u16, flags: u32) -> i32;
}

fn show_error(message: &str) {
    let text: Vec<u16> = std::ffi::OsStr::new(message).encode_wide().chain(Some(0)).collect();
    let caption: Vec<u16> = "S4GGZ".encode_utf16().chain(Some(0)).collect();
    unsafe { MessageBoxW(std::ptr::null_mut(), text.as_ptr(), caption.as_ptr(), 0x10); }
}

fn launch() -> Result<(), String> {
    let launcher = std::env::current_exe().map_err(|error| error.to_string())?;
    let root = launcher.parent().ok_or("Folderul programului nu poate fi gasit.")?;
    let directory = root.join("target").join("release");
    let executable = directory.join("s4ggz.exe");
    if !executable.is_file() {
        return Err(format!(
            "Executabilul aplicatiei lipseste:\n{}\n\nPastreaza S4GGZ.exe in folderul principal, impreuna cu folderul target.",
            executable.display()
        ));
    }
    // Preserve the existing Music location and the paths stored in the library.
    Command::new(&executable)
        .current_dir(&directory)
        .spawn()
        .map_err(|error| format!("Programul nu a putut fi pornit:\n{error}"))?;
    Ok(())
}

fn main() -> ExitCode {
    match launch() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => { show_error(&error); ExitCode::FAILURE }
    }
}
