# Compactare — 2 noiembrie 2026

Folderul a fost redus de la aproximativ **5,88 GB** la aproximativ **348 MB** (332 MiB), sub limita de 400 MB.

Au fost eliminate cache-urile de compilare debug/release, fișierele temporare de test, simbolurile PDB, cele patru directoare cu copii QA, executabilele anterioare și rapoartele QA vechi. Nu a fost executat `cargo clean` și nu a fost șters integral `target`.

Au fost păstrate launcherul, executabilul actual, ambele copii necesare de `vcruntime140.dll`, imaginile și animațiile, FFmpeg/FFprobe cu licențele, toate cele 15 fișiere din `target/release/Music`, sursele și testele versiunii actuale, fișierele Cargo și instrucțiunile de utilizare. Sursele și testele ocupă împreună sub 1 MB. Căile muzicii au rămas aceleași; baza de date și preferințele din afara folderului proiectului nu au fost ținte ale curățării.

Verificări după ștergere:

- 95 de fișiere protejate, verificate prin SHA-256 înainte și după: zero lipsuri și zero modificări.
- Launcherul și executabilul coincid cu `SHA256SUMS.txt`.
- FFmpeg a generat un MP3 dintr-un semnal sintetic, FFprobe a citit metadatele, iar FFmpeg l-a decodat integral fără erori. Fișierul de test a fost eliminat.
- Codul și executabilul nu au fost reconstruite după curățare, pentru a nu recrea artefactele eliminate. Rezultatul celor 165 de teste trecute pentru versiunea actuală este păstrat în `VERIFICARE-WINDOWS.txt`.

Utilizarea normală rămâne prin `S4GGZ.exe` sau `START_WINDOWS.bat`. Descărcările viitoare și recompilarea pot mări din nou folderul.
